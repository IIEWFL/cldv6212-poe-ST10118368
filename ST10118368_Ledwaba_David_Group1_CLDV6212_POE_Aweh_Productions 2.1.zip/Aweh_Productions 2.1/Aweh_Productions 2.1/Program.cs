﻿using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using System.Buffers.Text;
using System.Text;

//Conection String
string conString = "DefaultEndpointsProtocol=https;AccountName=awehproduction;AccountKey=qypvKxtFnqAZdj0fPMmZnCLm4x3myCKjcPDhhwcYOAiZb5CTEE7qGJzbHhbjmoF88vyupPXBG9/0+AStnedSMw==;EndpointSuffix=core.windows.net";

//Queue creation
string queueName = "aweh-productions-queue";
QueueClient queueClient = new QueueClient(conString, queueName, new QueueClientOptions { MessageEncoding = QueueMessageEncoding.Base64});

Console.WriteLine($"{queueName} is created.");
await queueClient.CreateIfNotExistsAsync();

//Insertion of Messages into Queue
Console.WriteLine($"\nInserting messages into {queueName}...");

//Message duo 1
await queueClient.SendMessageAsync("9910125015083:Waterfall Netcare:02/05/2023:P09987547649083");
await queueClient.SendMessageAsync("1245789630:03/06/2023:San Ridge Health Care:9910125015083");

//Message duo 2
await queueClient.SendMessageAsync("0101014815083:Botlalo Pharmacy:22/08/2023:J85967547649083");
await queueClient.SendMessageAsync("0243549630:30/09/2023:Botlalo Pharmacye:0101014815083");

//Message duo 3
await queueClient.SendMessageAsync("0501014816083:Ackermans Pharmacy:01/01/2023:P29875495791458");
await queueClient.SendMessageAsync("3575789630:27/02/2023:Lily Pharmacy:0501014816083");

//Message duo 4
await queueClient.SendMessageAsync("8505288055081:Lily Pharmacy:03/05/2023:J09987547646351");
await queueClient.SendMessageAsync("5985789630:15/06/2023:San Ridge Health Care:8505288055081");

//Message duo 5
await queueClient.SendMessageAsync("0005280015087:Waterfall Netcare:30/11/2023:J19987547648567");
await queueClient.SendMessageAsync("1025789630:31/12/2023:Ackermans Pharmacy:0005280015087");


//Peek messages into Queue
//Console.WriteLine($"\nPeeking into {queueName} messages");

//PeekedMessage[] peekedMessages = await queueClient.PeekMessagesAsync(maxMessages: 12);

//foreach (var peekedMessage in peekedMessages)
//{
//    Console.WriteLine($" Message : {peekedMessage.MessageId} | {peekedMessage.Body} | {peekedMessage.ExpiresOn} | {peekedMessage.DequeueCount}");

//}

////SendReceipt to View Information

//string messageContent1 = "1245789630:03/06/2023:San Ridge Health Care:9910125015083";
//string messageContent2 = "0243549630:30/09/2023:Botlalo Pharmacye:0101014815083";
//string messageContent3 = "3575789630:27/02/2023:Lily Pharmacy:0501014816083";
//string messageContent4 = "5985789630:15/06/2023:San Ridge Health Care:8505288055081";
//string messageContent5 = "1025789630:31/12/2023:Ackermans Pharmacy:0005280015087";

//Console.WriteLine("\nNew message insertion with Send Receipt");
////Send Receipt 1
//SendReceipt sendReceipt1 = await queueClient.SendMessageAsync(messageContent1);
////Send Receipt 2
//SendReceipt sendReceipt2 = await queueClient.SendMessageAsync(messageContent2);
////Send Receipt 3
//SendReceipt sendReceipt3 = await queueClient.SendMessageAsync(messageContent3);
////Send Receipt 4
//SendReceipt sendReceipt4 = await queueClient.SendMessageAsync(messageContent4);
////Send Receipt 5
//SendReceipt sendReceipt5 = await queueClient.SendMessageAsync(messageContent5);

////Receipt 1 population
//Console.WriteLine($"Message sent: {messageContent1}");
//Console.WriteLine($"Message ID:\t {sendReceipt1.MessageId}");
//Console.WriteLine($"Pop Receipt: {sendReceipt1.PopReceipt}\n");
////Receipt 2 population
//Console.WriteLine($"Message sent: {messageContent2}");
//Console.WriteLine($"Message ID:\t {sendReceipt2.MessageId}");
//Console.WriteLine($"Pop Receipt: {sendReceipt2.PopReceipt}\n");
////Receipt 3 population
//Console.WriteLine($"Message sent: {messageContent3}");
//Console.WriteLine($"Message ID:\t {sendReceipt3.MessageId}");
//Console.WriteLine($"Pop Receipt: {sendReceipt3.PopReceipt}\n");
////Receipt 4 population
//Console.WriteLine($"Message sent: {messageContent4}");
//Console.WriteLine($"Message ID:\t {sendReceipt4.MessageId}");
//Console.WriteLine($"Pop Receipt: {sendReceipt4.PopReceipt}\n");
////Receipt 5 population
//Console.WriteLine($"Message sent: {messageContent5}");
//Console.WriteLine($"Message ID:\t {sendReceipt5.MessageId}");
//Console.WriteLine($"Pop Receipt: {sendReceipt5.PopReceipt}\n");




Console.WriteLine("Complete....!");
