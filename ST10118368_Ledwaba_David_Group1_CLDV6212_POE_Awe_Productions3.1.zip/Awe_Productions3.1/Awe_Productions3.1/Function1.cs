using System;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Azure.Documents.SystemFunctions;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace Awe_Productions3._1
{
    public class Function1
    {
        [FunctionName("AwehProductions")]
        public async Task Run([QueueTrigger("aweh-productions-queue", Connection = "QueueConn")]string myQueueItem,
            [Table("AwehProductionMessage", Connection = "QueueConn")] CloudTable cloudTable, ILogger log)
        {
            try
            {
                //Delcare
                string id = "";
                string vaccineCentre = "";
                string vaccinationDate = "";
                string vaccineSerialNumber = "";
                long number;

                //Splitting the message into parts to store.
                String[] attributes = myQueueItem.Split(':');

                //Check whether first attribute is the ID or Vaccine Barcode
                string checkAttribute = attributes[0];

                if (checkAttribute.Count() == 13 && (Int64.TryParse(checkAttribute, out number)))
                {
                    id = attributes[0];
                    vaccineCentre = attributes[1];
                    vaccinationDate = attributes[2];
                    vaccineSerialNumber = attributes[3];

                }
                else
                {
                    vaccineSerialNumber = attributes[0];
                    vaccinationDate = attributes[1];
                    vaccineCentre = attributes[2];
                    id = attributes[3];
                }

                //New Message entity creation
                AwehMessageEntity awehMessageEntity = new AwehMessageEntity(id, vaccineCentre, vaccinationDate, vaccineSerialNumber);

                //Table Operationm to INSERT the Message Entity
                TableOperation insertOperation = TableOperation.Insert(awehMessageEntity);

                //Execution of the INSERT Operation
                await cloudTable.ExecuteAsync(insertOperation);

                //Logging mesaage details
                log.LogInformation($"Queue message successfully stored ID = {id} | Vaccination Centre = {vaccineCentre} | Vaccination Date = {vaccinationDate} | Vaccine Serial Number = {vaccineSerialNumber}");
            }
            catch (Exception ex) 
            {
                log.LogError("Processing Error: " + ex.Message);
            }
        }

        public class AwehMessageEntity : TableEntity
        {

            //Default Constructor
            public AwehMessageEntity() { }

            //Table entry/ setting up model
            public AwehMessageEntity(string id, string vaccineCentre, string vaccinationDate, string vaccineSerialNumber)
            {
                PartitionKey = "New Incoming Mesaage";
                RowKey = Guid.NewGuid().ToString();
                Id = id;
                VaccineCentre = vaccineCentre;
                VaccinationDate = vaccinationDate;
                VaccineSerialNumber = vaccineSerialNumber;

            }

            //Setters and Getters
            public string Id { get; set; }
            public string VaccineCentre { get; set; }
            public string VaccinationDate { get; set; }
            public string VaccineSerialNumber { get; set; }

        }
    }
}
